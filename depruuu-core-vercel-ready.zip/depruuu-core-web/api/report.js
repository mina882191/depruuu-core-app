module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const webhook = process.env.DISCORD_WEBHOOK_URL;
  if (!webhook) {
    return res.status(503).json({ error: 'Report system is not configured yet.' });
  }

  try {
    const body = req.body || {};
    const name = String(body.name || '').trim();
    const type = String(body.type || '').trim();
    const details = String(body.details || '').trim();
    const evidence = String(body.evidence || '').trim();

    if (!name || !type || !details) {
      return res.status(400).json({ error: 'Missing required fields.' });
    }

    const payload = {
      username: 'DEPRUUU CORE • Report Center',
      embeds: [{
        title: '🪻 New Community Report',
        color: 10125527,
        fields: [
          { name: 'Member', value: name.slice(0, 1024), inline: true },
          { name: 'Category', value: type.slice(0, 1024), inline: true },
          { name: 'Details', value: details.slice(0, 4000) },
          { name: 'Evidence', value: evidence ? evidence.slice(0, 1024) : '—' }
        ],
        footer: { text: 'DEPRUUU CORE · Report Center' },
        timestamp: new Date().toISOString()
      }]
    };

    const response = await fetch(webhook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      return res.status(502).json({ error: 'Discord webhook rejected the report.' });
    }

    return res.status(200).json({ ok: true });
  } catch (error) {
    console.error('Report error:', error);
    return res.status(500).json({ error: 'Could not send report.' });
  }
}
