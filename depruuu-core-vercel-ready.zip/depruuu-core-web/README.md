# ୨୧ DEPRUUU CORE — Vercel Ready

เว็บไซต์ Official Fan Community ของ DEPRUUU CORE

## Deploy to Vercel

1. อัปโหลดโฟลเดอร์นี้ขึ้น GitHub หรือ Import โปรเจกต์เข้า Vercel
2. ใน Vercel → Project Settings → Environment Variables เพิ่ม:
   - Name: `DISCORD_WEBHOOK_URL`
   - Value: **Discord Webhook URL ใหม่ของคุณ**
   - Environment: Production (และ Preview ถ้าต้องการ)
3. Deploy / Redeploy
4. ทดสอบแบบฟอร์มร้องเรียนที่ `/` → Report Center

## สำคัญ
Webhook ที่เคยส่งในแชตควรถูก Rotate/Recreate ก่อนใช้จริง เพราะ URL เดิมถือเป็น credential ลับ

เว็บไซต์ใช้ Vercel Serverless Function ที่ `/api/report` ดังนั้น Webhook จะไม่ถูกส่งไปฝั่ง browser
